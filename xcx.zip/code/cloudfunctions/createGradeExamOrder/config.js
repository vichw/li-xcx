module.exports = {
  // 微信支付配置
  wxpay: {

    mchId: '1721868032', // 李教练商户号
    apiKey: '3fd7355fc79f443a24a47eb04f8cf112', // 李教练API密钥

    // mchId: '1718016646', // 苏教练商户号
    // apiKey: '3fd7355fc79f443a24a47eb04f8cf4e6', // 苏教练API密钥
    tradeType: 'JSAPI',
    // 会员费金额配置（单位：分）
    vipAmount: 5000, // 50元
    // vipAmount: 1, // 0.01元
  }
};
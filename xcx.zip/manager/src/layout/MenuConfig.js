[
  { name: '首页', icon: 'home', path: '/home' },
  { name: '学生管理', icon: 'user', path: '/students' },
  { name: '荣誉管理', icon: 'trophy', path: '/honor' },
  { name: '注册管理', icon: 'file', path: '/register' },
  { name: '考级导出', icon: 'export', path: '/export-grade-exam' }
] 
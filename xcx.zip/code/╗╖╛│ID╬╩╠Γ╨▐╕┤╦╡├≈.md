# 环境ID问题修复说明

## 问题描述

创建报名缴费订单时，云函数报错：
```
"创建支付订单失败：env_id is empty."
```

## 问题原因

在微信支付调用中，使用了 `cloud.DYNAMIC_CURRENT_ENV` 作为环境ID，但这个值返回的是 `Symbol(SYMBOL_CURRENT_ENV)` 而不是实际的环境ID字符串，导致微信支付接口报错。

## 问题分析

### 错误的用法：
```javascript
const paymentResult = await cloud.cloudPay.unifiedOrder({
  // ... 其他参数
  envId: cloud.DYNAMIC_CURRENT_ENV,  // 这里返回的是 Symbol，不是字符串
  // ... 其他参数
});
```

### 日志显示：
```
2025-08-17T11:52:16.695Z  --------->{} Symbol(SYMBOL_CURRENT_ENV)
```

## 修复方案

### 1. 正确获取环境ID

**修改前：**
```javascript
envId: cloud.DYNAMIC_CURRENT_ENV,
```

**修改后：**
```javascript
// 获取环境ID
const envId = context.ENV || process.env.ENV || process.env.TCB_ENV;
console.log('环境ID:', envId);

// 使用环境ID
envId: envId,
```

### 2. 完整的修复代码

```javascript
// 云函数入口文件
const cloud = require('wx-server-sdk');
const wxpayConfig = require('./config');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();

// 创建报名缴费订单
exports.main = async (event, context) => {
  try {
    const wxContext = cloud.getWXContext();
    const openid = wxContext.OPENID;
    
    const { phoneNumber } = event;
    
    if (!phoneNumber) {
      return {
        success: false,
        message: '手机号不能为空'
      };
    }

    // 获取环境ID
    const envId = context.ENV || process.env.ENV || process.env.TCB_ENV;
    console.log('环境ID:', envId);

    // ... 其他代码

    // 调用微信支付统一下单
    const paymentResult = await cloud.cloudPay.unifiedOrder({
      body: '跆拳道入会费',
      outTradeNo: orderNo,
      spbillCreateIp: '127.0.0.1',
      subMchId: wxpayConfig.wxpay.mchId,
      totalFee: Math.round(amount * 100),
      envId: envId,  // 使用正确的环境ID
      functionName: 'registrationPaymentCallback'
    });

    // ... 其他代码
  } catch (e) {
    console.error('创建报名缴费订单失败', e);
    return {
      success: false,
      message: '创建订单失败',
      error: e
    };
  }
};
```

## 环境ID获取方式说明

### 1. context.ENV
- 从云函数上下文获取环境ID
- 最可靠的方式

### 2. process.env.ENV
- 从环境变量获取
- 备用方式

### 3. process.env.TCB_ENV
- 腾讯云开发环境变量
- 兼容性方式

## 修复的文件

- `createRegistrationPayment/index.js` - 已修复环境ID获取方式

## 部署说明

需要重新部署 `createRegistrationPayment` 云函数。

## 测试建议

1. **检查环境ID**：查看云函数日志，确认环境ID是否正确输出
2. **测试支付功能**：验证微信支付是否正常调用
3. **测试回调功能**：验证支付回调是否正常处理

## 注意事项

1. **环境ID格式**：确保环境ID是字符串格式，不是Symbol
2. **日志输出**：添加环境ID的日志输出，便于调试
3. **错误处理**：如果环境ID为空，应该有相应的错误处理

## 相关文档

- [微信云开发支付文档](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/openapi/pay.html)
- [云函数环境变量](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/guide/functions/env.html)

修复完成后，微信支付应该能够正常调用，不再出现 "env_id is empty" 的错误。 
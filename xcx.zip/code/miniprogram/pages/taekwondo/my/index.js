// 我的页面
const app = getApp();

Page({
  data: {
    isLogin: false, // 是否已登录
    phoneNumber: '', // 手机号
    userInfo: null, // 用户信息
    honorList: [], // 荣誉列表
    loading: false, // 加载状态
    showEditInfo: false, // 是否显示编辑个人信息表单
    // 编辑表单的数据
    formData: {
      name: '',
      avatar: '' // 头像URL
    },

    currentGradeInfo: {}, // 当前级别信息
    nextGradeInfo: {},    // 下一级别信息
    showGradeExamDialog: false, // 考级支付弹窗
    gradeExamPaid: false, // 是否已缴费
    gradeExamPayStatus: '未缴费',
    gradeExamPayTime: '',
    gradeExamScore: null, // 新增：考级成绩
    // 新增历史考级弹窗相关
    showGradeHistoryModal: false,
    gradeExamHistory: [],
    nextGradeExamInfo: null,
    // 会员状态相关
    membershipStatus: '', // 会员状态
    membershipMessage: '', // 会员状态消息
    remainingCount: 0, // 剩余次数
    membershipStartDate: '', // 会员开始日期
    membershipEndDate: '' // 会员结束日期
  },

  onLoad: function () {
    
    // 检查是否已登录
    this.checkLoginStatus();
  },
  
  onShow: function () {
    
    
    if (this.data.isLogin) {
      // 先加载用户数据，然后在回调中加载考级信息和会员状态
      this.loadUserData(() => {
        this.loadGradeInfo();
        // 加载考级缴费状态
        this.loadGradeExamPayStatus();
        
        // 直接从用户数据中获取会员状态信息，无需再次调用loadMembershipStatus
        if (this.data.userInfo) {
          const userInfo = this.data.userInfo;
          
          // 格式化日期显示
          const formatDate = (dateStr) => {
            if (!dateStr) return '';
            const date = new Date(dateStr);
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const day = date.getDate().toString().padStart(2, '0');
            return `${year}-${month}-${day}`;
          };
          
          this.setData({
            membershipStatus: userInfo.status || '',
            membershipMessage: '',
            remainingCount: userInfo.remaining_count || 0,
            membershipStartDate: formatDate(userInfo.membership_start_date),
            membershipEndDate: formatDate(userInfo.membership_end_date)
          });
        }
      });
    }
  },

  // 检查登录状态 - 优化版本
  checkLoginStatus: function () {
    // 使用app.js的统一登录状态检查
    app.checkLoginStatus((isLoggedIn, userInfo) => {
      if (isLoggedIn && userInfo) {                                
        // 格式化日期显示
        const formatDate = (dateStr) => {
          if (!dateStr) return '';
          const date = new Date(dateStr);
          const year = date.getFullYear();
          const month = (date.getMonth() + 1).toString().padStart(2, '0');
          const day = date.getDate().toString().padStart(2, '0');
          return `${year}-${month}-${day}`;
        };
        
        this.setData({
          isLogin: true,
          userInfo: userInfo,
          phoneNumber: userInfo.phoneNumber || '',
          membershipStatus: userInfo.status || '',
          membershipMessage: '',
          remainingCount: userInfo.remaining_count || 0,
          membershipStartDate: formatDate(userInfo.membership_start_date),
          membershipEndDate: formatDate(userInfo.membership_end_date)
        });
        // 加载用户荣誉数据
        this.loadGradeInfo();
        // 加载考级缴费状态
        this.loadGradeExamPayStatus();
        this.loadUserHonors();
      } else {
        // 未登录，清除页面状态
        this.setData({
          isLogin: false,
          userInfo: null,
          phoneNumber: '',
          honorList: [],
          formData: {
            name: '',
            avatar: ''
          }
        });
      }
    });
  },

  // 登录操作
  doLogin: function (e) {
    
    console.log('获取用户信息:',e.detail.userInfo)
    const phoneNumber = this.data.phoneNumber;  
    // 验证手机号
    if (!phoneNumber || phoneNumber.length !== 11) {
      wx.showToast({
        title: '请输入正确的手机号',
        icon: 'none'
      });
      return;
    }
    wx.showLoading({
      title: '登录中...',
      mask: true
    });

    // 调用云函数进行登录
    wx.cloud.callFunction({
          name: 'taekwondoFunctions',
          data: {
            type: 'userLogin',
            phoneNumber: phoneNumber
          },
          success: res => {

            wx.hideLoading();
            console.log('登录成功', res);
            let gradeImg =app.globalData.beltconfig.find(item => item.name === res.result.data.grade)?.image;
                    console.log('------------->',gradeImg)

                    console.log('------------',res.result.data)
            
                if (res.result && res.result.success) {
                  // 登录成功，使用app.js的统一状态管理

                  const userInfo = {
                    ...res.result.data,
                    vipPayTimeFmt:this.formatDateTime(res.result.data.vipPayTime),
                    gradeImg: gradeImg
                  };
                  
                  app.setLoginStatus(userInfo, phoneNumber);
                  
                  this.setData({
                    isLogin: true,
                    userInfo: userInfo
                  });
                  
                  // 加载用户荣誉数据
                  this.loadUserHonors();
                  
                  // 加载会员状态信息
                  // 格式化日期显示
                  const formatDate = (dateStr) => {
                    if (!dateStr) return '';
                    const date = new Date(dateStr);
                    const year = date.getFullYear();
                    const month = (date.getMonth() + 1).toString().padStart(2, '0');
                    const day = date.getDate().toString().padStart(2, '0');
                    return `${year}-${month}-${day}`;
                  };
                  
                  this.setData({
                    membershipStatus: userInfo.status || '',
                    membershipMessage: '',
                    remainingCount: userInfo.remaining_count || 0,
                    membershipStartDate: formatDate(userInfo.membership_start_date),
                    membershipEndDate: formatDate(userInfo.membership_end_date)
                  });
                  
                  wx.showToast({
                    title: '登录成功',
                    icon: 'success'
                  });
                } else {
                  // 登录失败
                  wx.showModal({
                    title: '登录失败',
                    content: res.result.message || '手机号未注册或系统错误，请联系管理员',
                    showCancel: false
                  });
                }
              },
              fail: err => {
                wx.hideLoading();
                console.error('登录失败', err);
                
                wx.showToast({
                  title: '登录失败，请稍后再试',
                  icon: 'none'
                });
              }
      });

  },

  // 退出登录
  logout: function () {
    wx.showModal({
      title: '确认退出',
      content: '确定要退出登录吗？',
      success: res => {
        if (res.confirm) {
          // 使用app.js的统一状态管理
          app.clearLoginStatus();
          
          this.setData({
            isLogin: false,
            userInfo: null,
            phoneNumber: '',
            honorList: [],
            formData: {
              name: '',
              avatar: ''
            }
          });
          
          wx.showToast({
            title: '已退出登录',
            icon: 'success'
          });
        }
      }
    });
  },

  // 工具函数：格式化时间
  formatDateTime: function(dateStr) {
    if (!dateStr) return '';
    const date = new Date(dateStr);
    const y = date.getFullYear();
    const m = (date.getMonth() + 1).toString().padStart(2, '0');
    const d = date.getDate().toString().padStart(2, '0');
    const h = date.getHours().toString().padStart(2, '0');
    const min = date.getMinutes().toString().padStart(2, '0');
    const s = date.getSeconds().toString().padStart(2, '0');
    return `${y}-${m}-${d} ${h}:${min}:${s}`;
  },

  // 加载用户数据
  loadUserData: function (callback) {
    const that = this;
    const phoneNumber = this.data.phoneNumber;
    
    if (!phoneNumber) {
      console.error('手机号不存在，无法加载用户数据');
      if (typeof callback === 'function') {
        callback();
      }
      return;
    }
    
    wx.cloud.callFunction({
      name: 'taekwondoFunctions',
      data: {
        type: 'getUserInfo',
        phoneNumber: phoneNumber
      },
      success: res => {
        console.log('获取用户信息成功', res.result.data);
        if (res.result && res.result.data) {
          let gradeImg = app.globalData.beltconfig.find(item => item.name === res.result.data.grade)?.image;
          
          // 判断会员状态 - 直接使用数据库中的isVipPaid字段
          let isVipPaid = res.result.data.isVipPaid ;
          let vipPayTimeFmt = '';
          
          // 如果已支付，格式化支付时间
          if (isVipPaid && res.result.data.vipPayTime) {
            vipPayTimeFmt = this.formatDateTime(res.result.data.vipPayTime);
          } else if (isVipPaid && res.result.data.membership_start_date) {
            // 如果没有支付时间但有会员开始日期，使用会员开始日期作为支付时间
            vipPayTimeFmt = this.formatDateTime(res.result.data.membership_start_date);
          }
          
          // 确保会员类型和价格信息存在
          const membership_type = res.result.data.membership_type || '';
          const membership_name = res.result.data.membership_name || '';
          const membership_price = res.result.data.membership_price || 0;
          
          const userInfo = {
            ...res.result.data,
            gradeImg: gradeImg,
            vipPayTimeFmt: vipPayTimeFmt,
            isVipPaid: isVipPaid,
            membership_type: membership_type,
            membership_name: membership_name,
            membership_price: membership_price
          };
          
          that.setData({
            userInfo: userInfo,
            formData: {
              name: res.result.data.name || '',
              avatar: res.result.data.avatar || ''
            }
          }, () => {
            // 更新全局状态和本地存储
            app.setLoginStatus(userInfo, phoneNumber);
            
            // 在setData的回调中执行callback
            if (typeof callback === 'function') {
              callback();
            }
          });
        }
      },
      fail: err => {
        console.error('获取用户信息失败', err);
        if (typeof callback === 'function') {
          callback();
        }
      }
    });
  },

  // 加载会员状态信息
  loadMembershipStatus: function() {
    const phoneNumber = this.data.phoneNumber;
    
    if (!phoneNumber) {
      return;
    }
    
    wx.cloud.callFunction({
      name: 'taekwondoFunctions',
      data: {
        type: 'checkMembershipStatus',
        phoneNumber: phoneNumber
      },
      success: res => {
        
        console.log('获取会员状态成功', res);
        if (res.result && res.result.success) {
          const membershipInfo = res.result.data;
          
          // 格式化日期显示
          const formatDate = (dateStr) => {
            if (!dateStr) return '';
            const date = new Date(dateStr);
            const year = date.getFullYear();
            const month = (date.getMonth() + 1).toString().padStart(2, '0');
            const day = date.getDate().toString().padStart(2, '0');
            return `${year}-${month}-${day}`;
          };
          
          this.setData({
            membershipStatus: membershipInfo.status || '',
            membershipMessage: membershipInfo.message || '',
            remainingCount: membershipInfo.remaining_count || 0,
            membershipStartDate: formatDate(membershipInfo.membership_start_date),
            membershipEndDate: formatDate(membershipInfo.membership_end_date)
          });
        } else {
          // 如果没有会员信息，设置默认值
          this.setData({
            membershipStatus: '未开通',
            membershipMessage: '暂无会员信息',
            remainingCount: 0,
            membershipStartDate: '',
            membershipEndDate: ''
          });
        }
      },
      fail: err => {
        console.error('获取会员状态失败', err);
        // 出错时设置默认值
        this.setData({
          membershipStatus: '未知',
          membershipMessage: '获取会员信息失败',
          remainingCount: 0,
          membershipStartDate: '',
          membershipEndDate: ''
        });
      }
    });
  },
 getRegex: function(){

  return  grade.match(/(\d+)段|级/);
 },
  // 加载用户荣誉
  loadUserHonors: function () {
    const that = this;
    that.setData({
      loading: true
    });
    
    wx.cloud.callFunction({
      name: 'taekwondoFunctions',
      data: {
        type: 'getUserHonors',
        phoneNumber:this.data.phoneNumber
      },
      success: res => {
        console.log('获取用户荣誉成功', res);
        
        that.setData({
          honorList: res.result.data || [],
          loading: false
        });
      },
      fail: err => {
        console.error('获取用户荣誉失败', err);
        that.setData({
          loading: false
        });
        
        wx.showToast({
          title: '获取荣誉数据失败',
          icon: 'none'
        });
      }
    });
  },



  // 显示编辑个人信息表单
  showEditForm: function () {     
    this.loadUserData();
    
    this.setData({
      showEditInfo: true
    });
  },

  // 隐藏编辑个人信息表单
  hideEditForm: function () {
    this.setData({
      showEditInfo: false
    });
  },

  // 表单输入事件处理
  inputFormField: function (e) {
    const field = e.currentTarget.dataset.field;
    const value = e.detail.value;
    
    // 更新对应字段的值
    this.setData({
      [`formData.${field}`]: value
    });
  },

  // 提交个人信息表单
  submitForm: function () {
    const formData = this.data.formData;
    
    // 表单验证
    if (!formData.name || formData.name.trim() === '') {
      wx.showToast({
        title: '请输入姓名',
        icon: 'none'
      });
      return;
    }
    
    wx.showLoading({
      title: '保存中...',
      mask: true
    });
    
    // 调用云函数更新用户信息
    wx.cloud.callFunction({
      name: 'taekwondoFunctions',
      data: {
        type: 'updateUserInfo',
        userInfo: {
          name: formData.name,
          avatar: formData.avatar,
          phoneNumber: this.data.phoneNumber
        }  
      },
      success: res => {
        wx.hideLoading();
        console.log('更新用户信息成功', res);
        
        if (res.result && res.result.success) {
          
          this.loadUserData();

          this.setData({
            showEditInfo: false
          })
        } else {
          wx.showToast({
            title: '保存失败，请稍后再试',
            icon: 'none'
          });
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('更新用户信息失败', err);
        
        wx.showToast({
          title: '保存失败，请稍后再试',
          icon: 'none'
        });
      }
    });
  },

  // 上传头像
  uploadAvatar: function () {
    const that = this;
    
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: res => {
        const tempFilePath = res.tempFilePaths[0];
        
        wx.showLoading({
          title: '上传中...',
          mask: true
        });
        
        // 上传图片到云存储
        const uploadTask = wx.cloud.uploadFile({
          cloudPath: `avatars/${Date.now()}.jpg`,
          filePath: tempFilePath,
          success: uploadRes => {
            console.log('上传成功', uploadRes);                        
            // 更新头像URL
            const fileID = uploadRes.fileID;
            that.setData(
              {                
                'formData.avatar': fileID // 使用字符串路径更新嵌套对象
               
            });
            
            wx.hideLoading();
            wx.showToast({
              title: '上传成功',
              icon: 'success'
            });
          },
          fail: err => {
            wx.hideLoading();
            console.error('上传失败', err);
            
            wx.showToast({
              title: '上传失败，请稍后再试',
              icon: 'none'
            });
          }
        });
      }
    });
  },



  // 处理会员费支付
  handleVipPay: function() {
    const { userInfo } = this.data;
    
    // 检查是否有会员类型和价格信息
    if (!userInfo.membership_type || !userInfo.membership_price) {
      wx.showToast({
        title: '会员信息不完整，请联系管理员',
        icon: 'none'
      });
      return;
    }
    
    wx.showModal({
      title: '确认支付会员费',
      content: `会员类型: ${userInfo.membership_type}\n会员卡: ${userInfo.membership_name || '标准卡'}\n金额: ¥${userInfo.membership_price}`,
      confirmText: '确认支付',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          this.createVipPayOrder();
        }
      }
    });
  },

  // 创建会员支付订单
  createVipPayOrder: function() {
    wx.showLoading({
      title: '正在创建订单...'
    });
    
    // 调用云函数获取支付参数
    wx.cloud.callFunction({
      name: 'taekwondoFunctions', 
      data: {
        studentId: this.data.userInfo._id,
        type: 'createVipPayment',
        membershipType: this.data.userInfo.membership_type,
        membershipName: this.data.userInfo.membership_name,
        membershipPrice: this.data.userInfo.membership_price
      }
    }).then(res => {
      wx.hideLoading();
      if(res.result.success) {
        this.startWxPay(res.result.payParams);
      } else {
        wx.showToast({
          title: res.result.error || '创建订单失败',
          icon: 'none'
        });
      }
    }).catch(err => {
      wx.hideLoading();
      wx.showToast({
        title: '创建订单失败',
        icon: 'none'
      });
      console.error('创建订单失败', err);
    });
  },

  // 发起微信支付
  startWxPay: function(payParams) {
    console.log('开始发起支付，参数:', payParams);
    
    // 检查支付参数
    if (!payParams || !payParams.payment) {
      console.error('支付参数错误:', payParams);
      wx.showToast({
        title: '支付参数错误',
        icon: 'none'
      });
      return;
    }

    wx.requestPayment({
      timeStamp: payParams.payment.timeStamp,
      nonceStr: payParams.payment.nonceStr,
      package: payParams.payment.package,
      signType: payParams.payment.signType,
      paySign: payParams.payment.paySign,
      success: () => {
        console.log('支付成功');
        // 支付成功后，主动查询订单状态
        if (payParams.outTradeNo) {
          this.checkOrderStatus(payParams.outTradeNo);
        } else {
          wx.showToast({
            title: '未获取到订单号',
            icon: 'none'
          });
        }
      },
      fail: (err) => {
        console.error('支付失败', err);
        // 支付失败时，也查询订单状态，因为可能是用户取消支付
        if (payParams.outTradeNo) {
          this.checkOrderStatus(payParams.outTradeNo);
        } else {
          wx.showToast({
            title: '支付失败',
            icon: 'none'
          });
        }
      }
    });
  },

  // 查询订单状态
  checkOrderStatus: function(orderNo) {
    console.log('查询订单状态:', orderNo);
    wx.showLoading({
      title: '查询订单状态...'
    });

    // 添加重试机制
    const maxRetries = 3;
    const retryInterval = 2000; // 2秒
    let retryCount = 0;

    const checkStatus = () => {
      wx.cloud.callFunction({
        name: 'taekwondoFunctions',
        data: {
          type: 'checkOrderStatus',
          orderNo: orderNo
        }
      }).then(res => {
        
        wx.hideLoading();
        console.log('订单状态查询结果:', res);
        
        if (res.result && res.result.success) {
          if (res.result.data.status === 1) {
            wx.showToast({
              title: '支付成功'
            });
            
            // 更新本地用户信息的支付状态
            if (this.data.userInfo) {
              const userInfo = this.data.userInfo;
              userInfo.isVipPaid = true; // 设置为布尔值true，对应数据库中的1
              
              if (res.result.data.pay_time) {
                userInfo.vipPayTime = res.result.data.pay_time;
                userInfo.vipPayTimeFmt = this.formatDateTime(res.result.data.pay_time);
              }
              
              this.setData({ userInfo: userInfo });
              
              // 更新全局状态
              app.setLoginStatus(userInfo, this.data.phoneNumber);
            }
            
            this.loadUserData(); // 刷新用户信息
          } else if (retryCount < maxRetries) {
            // 如果订单未支付成功且未达到最大重试次数，则继续重试
            retryCount++;
            setTimeout(() => {
              checkStatus();
            }, retryInterval);
          } else {
            wx.showToast({
              title: '支付处理中',
              icon: 'none'
            });
          }
        } else {
          wx.showToast({
            title: '查询订单失败',
            icon: 'none'
          });
        }
      }).catch(err => {
        wx.hideLoading();
        console.error('查询订单状态失败:', err);
        if (retryCount < maxRetries) {
          // 如果查询失败且未达到最大重试次数，则继续重试
          retryCount++;
          setTimeout(() => {
            checkStatus();
          }, retryInterval);
        } else {
          wx.showToast({
            title: '查询订单失败',
            icon: 'none'
          });
        }
      });
    };

    // 开始第一次查询
    checkStatus();
  },

  // 加载考级信息
  loadGradeInfo: function() {
    const that = this;
    if (!that.data.userInfo) {
      console.log('用户信息未加载完成，跳过加载考级信息');
      return;
    }
    
    // 查询 configs，type=belt_level，获取所有级别
    wx.cloud.database().collection('configs')
      .where({ type: 'belt_level' })
      .get({
        success: res => {
          const beltList = res.data;
          
          // 默认值
          let current = null;
          let next = null;
          
          // 如果用户有等级信息，找到对应的当前级别和下一级别
          if (that.data.userInfo.grade) {
            // 找到当前级别
            current = beltList.find(item => item.name === that.data.userInfo.grade);
            
            // 找到下一级别
            if (current) {
              next = beltList.find(item => item.index === current.index + 1);
            }
          } else {
            // 如果用户没有等级信息，默认使用最低级别
            if (beltList.length > 0) {
              // 找到索引最小的级别作为当前级别
              current = beltList.reduce((min, item) => 
                (item.index < min.index) ? item : min, beltList[0]);
              
              // 找到下一级别
              next = beltList.find(item => item.index === current.index + 1);
            }
          }
          
          that.setData({
            currentGradeInfo: current || {},
            nextGradeInfo: next || {}
          }, () => {
            that.loadNextGradeExamInfo();
          });
          
          // 查询最近一次考级成绩
          that.loadLatestGradeExamScore();
        },
        fail: err => {
          console.error('加载考级信息失败', err);
          wx.showToast({
            title: '加载考级信息失败',
            icon: 'none'
          });
        }
      });
  },

  // 新增：查询下一级别的报名/缴费信息
  loadNextGradeExamInfo: function() {
    const studentId = this.data.userInfo && this.data.userInfo._id;
    const nextIndex = this.data.nextGradeInfo && this.data.nextGradeInfo.index;
    if (!studentId || nextIndex === undefined) {
      this.setData({ nextGradeExamInfo: null });
      return;
    }
    wx.cloud.database().collection('gradeExams')
      .where({
        student_id: studentId,
        next_index: nextIndex
      })
      .orderBy('create_time', 'desc')
      .limit(1)
      .get({
        success: res => {
          if (res.data && res.data.length > 0) {
            this.setData({ nextGradeExamInfo: res.data[0] });
          } else {
            this.setData({ nextGradeExamInfo: null });
          }
        },
        fail: err => {
          this.setData({ nextGradeExamInfo: null });
        }
      });
  },

  // 新增：查询最近一次考级成绩
  loadLatestGradeExamScore: function() {
    const that = this;
    const studentId = that.data.userInfo && that.data.userInfo._id;
    if (!studentId) return;
    wx.cloud.database().collection('gradeExams')
      .where({ student_id: studentId })
      .orderBy('create_time', 'desc')
      .limit(1)
      .get({
        success: res => {
          if (res.data && res.data.length > 0) {
            that.setData({ gradeExamScore: res.data[0] });
          } else {
            that.setData({ gradeExamScore: null });
          }
        },
        fail: err => {
          that.setData({ gradeExamScore: null });
        }
      });
  },

  // 报名考级
  handleGradeExamApply: function() {
    const { userInfo, nextGradeInfo } = this.data;
    
    // 移除会员费校验，考级与会员费无依赖关系
    
    if (!userInfo.avatar) {
      wx.showModal({
        title: '请先上传头像',
        content: '请在个人信息中维护头像后再报名考级',
        showCancel: false
      });
      return;
    }
    
    if (!nextGradeInfo.name) {
      wx.showToast({ title: '暂无下一级别可报名', icon: 'none' });
      return;
    }
    wx.showModal({
      title: '确认报名考级',
      content: `是否确认支付 ￥${nextGradeInfo.value} 报名 ${nextGradeInfo.name}？`,
      confirmText: '确认支付',
      cancelText: '取消',
      success: (res) => {
        if (res.confirm) {
          this.handleGradeExamPay();
        }
      }
    });
  },

  // 确认并支付考级报名费
  handleGradeExamPay: function() {
    const { userInfo, currentGradeInfo, nextGradeInfo } = this.data;
    const that = this;
    wx.showLoading({ title: '创建订单...' });
    wx.cloud.callFunction({
      name: 'createGradeExamOrder',
      data: {
        studentId: userInfo._id,
        currentIndex: currentGradeInfo.index,
        currentGrade: currentGradeInfo.name,
        avatar: userInfo.avatar
      },
      success: res => {
        wx.hideLoading();
        if (res.result.success) {
          that.startGradeExamPay(res.result.payParams);
        } else {
          wx.showToast({ title: res.result.error || '创建订单失败', icon: 'none' });
        }
      },
      fail: err => {
        wx.hideLoading();
        wx.showToast({ title: '创建订单失败', icon: 'none' });
      }
    });
  },

  // 发起微信支付
  startGradeExamPay: function(payParams) {
    const that = this;
    wx.requestPayment({
      timeStamp: payParams.payment.timeStamp,
      nonceStr: payParams.payment.nonceStr,
      package: payParams.payment.package,
      signType: payParams.payment.signType,
      paySign: payParams.payment.paySign,
      success: () => {
        if (payParams.outTradeNo) {
          that.checkGradeExamOrderStatus(payParams.outTradeNo);
        } else {
          wx.showToast({ title: '未获取到订单号', icon: 'none' });
        }
      },
      fail: (err) => {
        if (payParams.outTradeNo) {
          that.checkGradeExamOrderStatus(payParams.outTradeNo);
        } else {
          wx.showToast({ title: '支付失败', icon: 'none' });
        }
      }
    });
  },

  // 查询考级订单状态
  checkGradeExamOrderStatus: function(orderNo) {
    const that = this;
    wx.showLoading({ title: '查询订单状态...' });
    wx.cloud.callFunction({
      name: 'taekwondoFunctions',
      data: { 
        type: 'checkOrderStatus',
        orderNo: orderNo
      },
      success: res => {
        wx.hideLoading();
        if (res.result && res.result.success && res.result.data.status === 1) {
          wx.showToast({ title: '考级报名成功' });
          // 新增：保存缴费状态和时间
          that.setData({
            gradeExamPayStatus: '已缴费',
            gradeExamPayTime: that.formatDateTime(res.result.data.pay_time),
            gradeExamPaid: true
          });
          that.loadGradeInfo(); // 刷新考级信息
        } else {
          wx.showToast({ title: '支付未完成', icon: 'none' });
        }
      },
      fail: err => {
        wx.hideLoading();
        console.error('查询考级订单状态失败:', err);
        wx.showToast({ title: '查询订单失败', icon: 'none' });
      }
    });
  },

  // 查询当前用户最新的考级报名订单状态
  loadGradeExamPayStatus: function() {
    const that = this;
    const studentId = this.data.userInfo && this.data.userInfo._id;
    if (!studentId) {
      that.setData({
        gradeExamPaid: false,
        gradeExamPayStatus: '未缴费',
        gradeExamPayTime: ''
      });
      return;
    }
    wx.cloud.database().collection('orders')
      .where({
        student_id: studentId,
        order_type: 2, // 考级报名
        status: 1      // 已支付
      })
      .orderBy('pay_time', 'desc')
      .limit(1)
      .get({
        success: res => {
          if (res.data && res.data.length > 0) {
            that.setData({
              gradeExamPaid: true,
              gradeExamPayStatus: '已缴费',
              gradeExamPayTime: that.formatDateTime(res.data[0].pay_time)
            });
          } else {
            that.setData({
              gradeExamPaid: false,
              gradeExamPayStatus: '未缴费',
              gradeExamPayTime: ''
            });
          }
        },
        fail: err => {
          that.setData({
            gradeExamPaid: false,
            gradeExamPayStatus: '未缴费',
            gradeExamPayTime: ''
          });
        }
      });
  },

  // 显示历史考级弹窗
  showGradeHistory() {
    this.setData({ showGradeHistoryModal: true });
    this.fetchGradeExamHistory();
  },

  // 关闭历史考级弹窗
  closeGradeHistory() {
    this.setData({ showGradeHistoryModal: false });
  },

  // 获取历史考级数据
  async fetchGradeExamHistory() {
    const userInfo = this.data.userInfo;
    if (!userInfo || !userInfo._id) return;
    wx.showLoading({ title: '加载中' });
    try {
      const res = await wx.cloud.callFunction({
        name: 'taekwondoFunctions',
        data: {
          type: 'getGradeExamHistory',
          student_id: userInfo._id
        }
      });
      wx.hideLoading();
      this.setData({ gradeExamHistory: res.result || [] });
    } catch (e) {
      wx.hideLoading();
      wx.showToast({ title: '加载失败', icon: 'none' });
    }
  },

  // 跳转到历史考级页面
  goToGradeHistory() {
    wx.navigateTo({
      url: '/pages/taekwondo/grade-history/index'
    });
  },
}); 
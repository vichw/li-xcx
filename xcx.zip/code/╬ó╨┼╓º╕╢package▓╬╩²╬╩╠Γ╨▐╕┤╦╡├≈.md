# 微信支付package参数问题修复说明

## 问题描述

用户点击"确认缴费"后，弹出错误提示："调用支付JSAPI缺少参数: total_fee"

从控制台日志可以看出，`payment` 对象中的 `package` 参数值是 `"prepay_id="`，这是不完整的。正常情况下 `package` 应该是 `"prepay_id=wx1234567890abcdef"` 这样的格式。

## 问题分析

### 1. 根本原因
微信支付统一下单接口返回的 `package` 参数不完整，导致小程序调用 `wx.requestPayment` 时参数错误。

### 2. 可能的原因
1. **缺少必要参数**：微信支付统一下单调用时缺少 `tradeType` 和 `openid` 参数
2. **商户配置问题**：商户号、API密钥等配置可能有问题
3. **环境配置问题**：云开发环境ID配置可能有问题

## 修复方案

### 1. 添加缺失的微信支付参数

在 `createRegistrationPayment/index.js` 中为微信支付统一下单调用添加了必要参数：

```javascript
// 修复前
const paymentResult = await cloud.cloudPay.unifiedOrder({
  body: '跆拳道入会费',
  outTradeNo: orderNo,
  spbillCreateIp: '127.0.0.1',
  subMchId: wxpayConfig.wxpay.mchId,
  totalFee: Math.round(amount * 100),
  envId: envId,
  functionName: 'registrationPaymentCallback'
});

// 修复后
const paymentParams = {
  body: '跆拳道入会费',
  outTradeNo: orderNo,
  spbillCreateIp: '127.0.0.1',
  subMchId: wxpayConfig.wxpay.mchId,
  totalFee: Math.round(amount * 100),
  envId: envId,
  functionName: 'registrationPaymentCallback',
  tradeType: 'JSAPI',  // 新增：交易类型
  openid: openid       // 新增：用户openid
};
```

### 2. 添加详细日志记录

为了便于调试，添加了详细的日志记录：

```javascript
console.log('微信支付统一下单参数:', JSON.stringify(paymentParams, null, 2));
console.log('微信支付返回结果:', JSON.stringify(paymentResult, null, 2));
console.log('payment对象:', JSON.stringify(paymentResult.payment, null, 2));
```

### 3. 参数验证优化

在云函数中添加了更严格的参数验证：

```javascript
// 检查payment对象是否包含必要参数
if (!paymentResult.payment || !paymentResult.payment.timeStamp || !paymentResult.payment.nonceStr || !paymentResult.payment.package || !paymentResult.payment.signType || !paymentResult.payment.paySign) {
  console.error('微信支付返回的payment对象缺少必要参数:', paymentResult.payment);
  return {
    success: false,
    message: '微信支付参数不完整'
  };
}
```

## 微信支付参数说明

### cloud.cloudPay.unifiedOrder 必要参数：

1. **body**: 商品描述
2. **outTradeNo**: 商户订单号
3. **spbillCreateIp**: 终端IP
4. **subMchId**: 商户号
5. **totalFee**: 订单总金额（分）
6. **envId**: 环境ID
7. **functionName**: 支付结果通知回调云函数
8. **tradeType**: 交易类型（JSAPI）
9. **openid**: 用户openid

### wx.requestPayment 必要参数：

1. **timeStamp**: 时间戳
2. **nonceStr**: 随机字符串
3. **package**: 统一下单接口返回的 prepay_id 参数值
4. **signType**: 签名类型
5. **paySign**: 签名

## 排查步骤

### 1. 检查云函数日志
查看云函数执行日志，确认：
- 微信支付统一下单参数是否完整
- 返回的payment对象是否包含完整的package参数
- 是否有其他错误信息

### 2. 检查微信支付配置
确认以下配置是否正确：
- 商户号 (mchId): '1718016646'
- API密钥 (apiKey): '3fd7355fc79f443a24a47eb04f8cf4e6'
- 环境ID (envId): 从context.ENV获取

### 3. 检查小程序日志
查看小程序控制台日志，确认：
- 云函数返回的参数是否正确
- package参数是否完整（应该包含prepay_id值）

## 常见问题及解决方案

### 1. package参数为空或只有"prepay_id="
**原因**：微信支付统一下单失败或参数不完整
**解决**：检查tradeType和openid参数是否正确传递

### 2. 商户号配置错误
**原因**：subMchId参数值不正确
**解决**：确认商户号配置是否正确

### 3. API密钥错误
**原因**：apiKey配置不正确
**解决**：检查API密钥是否正确

### 4. 环境ID错误
**原因**：envId参数不正确
**解决**：确认云开发环境ID配置

## 测试建议

### 1. 测试环境
- 使用测试商户号
- 使用小额测试金额（如0.01元）

### 2. 测试步骤
1. 提交报名信息
2. 点击"确认缴费"
3. 检查云函数日志中的统一下单参数
4. 检查返回的payment对象
5. 确认支付弹窗是否正常显示

### 3. 预期结果
- 云函数成功调用微信支付统一下单
- 返回完整的payment对象，包含正确的package参数
- 小程序正常弹出支付界面

## 部署说明

需要重新部署以下文件：
1. `createRegistrationPayment/index.js` - 添加微信支付必要参数和日志

## 后续优化

### 1. 错误处理优化
- 添加更详细的错误提示
- 提供重试机制

### 2. 监控和日志
- 添加支付成功率监控
- 完善错误日志记录

### 3. 配置管理
- 统一管理微信支付配置
- 支持多环境配置 
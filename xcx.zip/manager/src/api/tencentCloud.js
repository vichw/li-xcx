import COS from 'cos-js-sdk-v5';

const cos = new COS({
  Secret
